// File: users.js
const users = [
    { username: 'user1', password: 'pass1' },
    { username: 'user2', password: 'pass2' },
    // Tambahkan pengguna lain jika diperlukan
];

module.exports = users;